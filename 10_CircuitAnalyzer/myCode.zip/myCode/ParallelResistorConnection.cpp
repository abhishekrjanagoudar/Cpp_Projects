#include "ParallelResistorConnection.h"

ParallelResistorConnection::ParallelResistorConnection
    (std::string name) : ResistorConnection(name) {
}

char ParallelResistorConnection::separator() const {
    return '|';
}

float ParallelResistorConnection::nominalValue() const {
    float total = 0.0f;
    for (const auto& r : resistors) {
        total += 1.0f / r->nominalValue();
    }
    return total == 0.0f ? 0.0f : 1.0f / total;
}

float ParallelResistorConnection::minimalValue() const {
    float total = 0.0f;
    for (const auto& r : resistors) {
        total += 1.0f / r->minimalValue();
    }
    return total == 0.0f ? 0.0f : 1.0f / total;
}

float ParallelResistorConnection::maximumValue() const {
    float total = 0.0f;
    for (const auto& r : resistors) {
        total += 1.0f / r->maximumValue();
    }
    return total == 0.0f ? 0.0f : 1.0f / total;
}
