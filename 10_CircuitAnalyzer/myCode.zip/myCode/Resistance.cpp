#include "Resistance.h"

#include <cmath>
#include <sstream>

Resistance::Resistance(std::string name): name{name} {
}

Resistance::~Resistance() {
}

std::string Resistance::getName() const {
    return name;
}

std::string Resistance::components() const {
    return "";
}

std::string Resistance::toString() const {
    std::string result = getName() + components() + "=";
    result += std::to_string(nominalValue()) + " Ohm";
    return result;
}

std::ostream& operator<< (std::ostream& out, Resistance& resistor) {
    out << resistor.toString();
    return out;
}

void Resistance::write(std::ostream &out) {
    float nom = nominalValue();
    float maxV = maximumValue();
    float minV = minimalValue();
    float tol = (nom > 0.0f) ? (maxV - minV) / (2.0f * nom) : 0.0f;
    
    out << getName() << components() << ";" 
        << nom << ";" 
        << tol << "\n";
}
